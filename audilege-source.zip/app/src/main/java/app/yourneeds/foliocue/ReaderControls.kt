package app.yourneeds.foliocue

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.io.File
import java.util.Locale

internal data class TrackProgress(val elapsedMs: Int, val durationMs: Int)

private fun clockLabel(ms: Int): String {
    val seconds = ms / 1000
    return if (seconds >= 3600) String.format(Locale.ROOT, "%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60)
    else String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60)
}

@Composable
internal fun ListeningArtwork(
    book: Publication, online: OnlineBook?, file: File, covers: CoverStore, chapter: Int, modifier: Modifier,
) {
    BoxWithConstraints(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val artworkWidth = (maxHeight * 0.52f).coerceIn(72.dp, 236.dp)
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            BookCover(book.title, covers, "player:${file.absolutePath}", {
                runCatching { online?.catalog?.cover(online.detail.id) }.getOrNull()
                    ?: book.cover?.let(book::open)
            }, Modifier.width(artworkWidth).aspectRatio(0.76f))
            Text(book.title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            val author = online?.detail?.author.orEmpty().ifBlank { book.author }
            if (author.isNotBlank()) Text(author, style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center,
                maxLines = 2, overflow = TextOverflow.Ellipsis)
            val label = book.contents.firstOrNull { it.path == book.spine[chapter].path }?.label.orEmpty()
            Text(label.ifBlank { stringResource(R.string.section, chapter + 1, book.spine.size) },
                style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

@Composable
internal fun ReaderDock(
    mode: Mode, chapter: Int, chapterCount: Int, progress: TrackProgress?, speed: Float,
    playing: Boolean, loading: Boolean, audioAvailable: Boolean, onPrevious: () -> Unit,
    onNext: () -> Unit, onContents: () -> Unit, onSpeed: () -> Unit, onPlay: () -> Unit,
) {
    Surface(color = MaterialTheme.colorScheme.surfaceContainer, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Column(Modifier.widthIn(max = 600.dp).fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                if (mode != Mode.Read && progress != null) {
                    val track = stringResource(R.string.track_progress)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(clockLabel(progress.elapsedMs), style = MaterialTheme.typography.labelSmall)
                        Text(track, style = MaterialTheme.typography.labelSmall)
                        Text(clockLabel(progress.durationMs), style = MaterialTheme.typography.labelSmall)
                    }
                    LinearProgressIndicator(
                        progress = { progress.elapsedMs.toFloat() / progress.durationMs },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).semantics { contentDescription = track },
                    )
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    val previous = stringResource(R.string.chapter_previous)
                    val next = stringResource(R.string.chapter_next)
                    IconButton(enabled = chapter > 0, onClick = onPrevious,
                        modifier = Modifier.semantics { contentDescription = previous }) {
                        Text("‹", style = MaterialTheme.typography.headlineMedium)
                    }
                    if (mode == Mode.Read) {
                        TextButton(onClick = onContents) {
                            Text(stringResource(R.string.section_short, chapter + 1, chapterCount))
                        }
                    } else {
                        Button(enabled = audioAvailable && !loading, onClick = onPlay,
                            modifier = Modifier.widthIn(min = 116.dp)) {
                            Text(stringResource(if (loading) R.string.connecting else if (playing) R.string.pause else R.string.play))
                        }
                    }
                    IconButton(enabled = chapter < chapterCount - 1, onClick = onNext,
                        modifier = Modifier.semantics { contentDescription = next }) {
                        Text("›", style = MaterialTheme.typography.headlineMedium)
                    }
                }
                if (mode != Mode.Read) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(onClick = onContents) { Text(stringResource(R.string.contents)) }
                    val speedLabel = stringResource(R.string.speed)
                    TextButton(onClick = onSpeed, modifier = Modifier.semantics { contentDescription = speedLabel }) {
                        Text(String.format(Locale.getDefault(), "%.2f×", speed))
                    }
                }
            }
        }
    }
}

